package com.example.vit;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;

public class StaffDash extends AppCompatActivity {
    DBHelper dbHelper;
    String id,na,pa,tok;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_dash);


        dbHelper=new DBHelper(this);
        Cursor res = dbHelper.GetSQLiteDatabaseRecords();

        while (res.moveToNext()) {
            id = res.getString(0);
            na = res.getString(1);
            pa = res.getString(2);
            tok = res.getString(3);
        }

        Log.e("na",""+na);
        Log.e("pa",""+pa);
        Log.e("tok",""+tok);


    }
}